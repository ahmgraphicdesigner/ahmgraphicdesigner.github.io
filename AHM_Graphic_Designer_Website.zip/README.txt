AHM GRAPHIC DESIGNER — FREE PORTFOLIO WEBSITE

Files:
- index.html: complete responsive website

Publish free with GitHub Pages:
1. Sign in to https://github.com/ or create a free account.
2. Create a new public repository named exactly: ahmgraphicdesigner.github.io
3. Upload index.html to the repository root (not inside another folder).
4. Open repository Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish. Your website address will be:
   https://ahmgraphicdesigner.github.io/

Before publishing:
- Replace the sample portfolio tiles with real project images and descriptions.
- Add your professional email/contact details if you want them public.
- Confirm the Instagram profile link is correct.

Google visibility:
- After the site is live, add the site to Google Search Console.
- Verify ownership and submit https://ahmgraphicdesigner.github.io/sitemap.xml
  (A sitemap can be added later; Google can also discover a simple site through URL inspection.)
- Use URL Inspection -> Request indexing.
- Indexing and ranking are not guaranteed or instant.
